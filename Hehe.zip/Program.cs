﻿namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleInput Cio = new ConsoleInput();
            Cio.Input(args);
        }
    }
}
