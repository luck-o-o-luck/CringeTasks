﻿using System;
using System.Collections.Generic;

namespace Test
{
    public enum TaskStatus
    {
        New = 0,
        Process,
        Finished
    }
}
