﻿using System;
using System.Collections.Generic;

namespace Test
{
    class GroupTask
    {
        public string Name { get; set; }

        public List<Task> Tasks = new List<Task>();
    }
}
